using Terraria.ModLoader;

namespace GodWingsMod
{
	public class GodWingsMod : Mod
	{
		public GodWingsMod()
		{
		}
	}
}