﻿using IL.Terraria;
using System.CodeDom.Compiler;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace GodWingsMod.Items
{
	public class CelestialEye : ModItem
	{
		public override void SetStaticDefaults()
		{
			// DisplayName.SetDefault("Lol"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("Cosmic relic!!!");
		}

		public override void SetDefaults()
		{
			item.damage = 50000;
			item.melee = true;
			item.width = 40;
			item.height = 40;
			item.useTime = -1;
			item.useAnimation = 20;
			item.useStyle = 5;
			item.knockBack = 20;
			item.value = 10000;
			item.rare = -12;
			item.UseSound = SoundID.Item103;
			item.autoReuse = true;
			item.shoot = ProjectileID.VortexBeaterRocket;
			item.shootSpeed = 20;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.MeteoriteBar, 10000);
			recipe.AddIngredient(ItemID.LunarBar, 2000);
			recipe.AddIngredient(ItemID.FragmentNebula, 1000);
			recipe.AddIngredient(ItemID.FragmentSolar, 1000);
			recipe.AddIngredient(ItemID.FragmentStardust, 1000);
			recipe.AddIngredient(ItemID.FragmentVortex, 1000);
			recipe.AddIngredient(ItemID.CrystalShard, 1000);
			recipe.AddIngredient(ItemID.SoulofLight, 500);
			recipe.AddIngredient(ItemID.SoulofNight, 500);
			recipe.AddIngredient(ItemID.SoulofSight, 500);
			recipe.AddIngredient(ItemID.Lens, 250);
			recipe.AddIngredient(ItemID.PurpleDye, 10);
			recipe.AddIngredient(ItemID.BlackLens, 5);
			recipe.AddIngredient(ItemID.EyeballStatue, 1);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}