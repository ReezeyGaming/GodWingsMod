using Terraria;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Terraria.ID;

namespace GodWingsMod.Items
{
	[AutoloadEquip(EquipType.Wings)]
	public class CelestialSoul : ModItem
	{
		public override bool Autoload(ref string name)
		{
			return !GetInstance<GodWingsConfigServer>().DisableCelestialWings;
		}

		public override void SetStaticDefaults() {

			Tooltip.SetDefault("Celestial Speed !!!" + "\nIncreases jump speed" + "\nIncreases max breath" + "\nIncreases mele speed" + "\nIncreases damage" + "\nAllow infinite flight" + "\nGreatly increase life regen" + "\nImmune to lava" );		
		}

		public override void SetDefaults() {
			item.width = 22;
			item.height = 20;
			item.value = 10000000;
			item.rare = -12;
			item.accessory = true;
			item.defense = 20;
			item.lifeRegen = 50;
		}
		public override void UpdateAccessory(Player player, bool hideVisual) {
			player.wingTimeMax = 999999999;
		}

		public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising,
			ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend) {
			ascentWhenFalling = 0.85f;
			ascentWhenRising = 0.85f;
			maxCanAscendMultiplier = 1f;
			maxAscentMultiplier = 100f;
			constantAscend = 0.535f;
		}

		public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration) {
			speed = 100f;
			acceleration *= 2.5f;
		}
		
		
			public override void UpdateEquip(Player player)
			{
				player.accRunSpeed = 99.8f;				
				player.moveSpeed += 2.1f;
			    player.runAcceleration = 0.3f;
				player.maxRunSpeed += 2.1f;
				player.noFallDmg = true;
				player.autoJump = false;
				player.jumpSpeedBoost += 2.5f;	
			    player.allDamage += 0.5f;
			    player.waterWalk = true;
			    player.lavaImmune = true;
			    player.breathMax = 400;
			    player.meleeSpeed += 0.5f;
			    player.maxFallSpeed += 5;
			}
		    

			public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.WingsNebula, 1);
			recipe.AddIngredient(ItemID.WingsSolar, 1);
			recipe.AddIngredient(ItemID.WingsStardust, 1);
			recipe.AddIngredient(ItemID.WingsVortex, 1);
			recipe.AddIngredient(ItemID.LunarBar, 250);
			recipe.AddIngredient(ItemID.SoulofFlight, 250);
			recipe.AddIngredient(ItemID.SoulofFright, 100);
			recipe.AddIngredient(ItemID.SoulofLight, 150);
			recipe.AddIngredient(ItemID.SoulofMight, 100);
			recipe.AddIngredient(ItemID.SoulofNight, 150);
			recipe.AddIngredient(ItemID.SoulofSight, 100);
			recipe.AddIngredient(ItemID.FireFeather, 1);
			recipe.AddIngredient(ItemID.IceFeather, 1);
			recipe.AddIngredient(ItemID.PixieDust, 500);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
    }
}